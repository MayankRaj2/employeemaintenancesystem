import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';
//import { Employee } from '../model/employee';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { User } from '../model/User';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
 /*  employee: Employee = new Employee();
  empIdStatus : boolean = false;
  nameStatus : boolean = false;
  panStatus : boolean = false;
  designations : String[] = ['Analyst','Senior Analyst','Consultant','Associate Consultant','Senior Consultant','Manager','Senior Manager'];
  domains : String[] = ['Java', 'DevOps', 'AWS', 'Angular', 'SAP', 'Python'];
  dateOfJoining : any = '';
  dateOfBirth : any = '';
  designationStatus : boolean = false;
  domainStatus : boolean = false;
  salaryStatus : boolean = false;
  passwordStatus : boolean = false;
  emailStatus : boolean = false;
  emp : Employee;
  public barLabel: string = "Password strength:";
  public myColors = ['#DD2C00', '#FF6D00', '#FFD600', '#AEEA00', '#00C853']; */
  user: User =new User();
  userIdStatus : boolean =false;
  userFirstNameStatus : boolean = false;
  userLastNameStatus : boolean = false;
  passwordStatus : boolean = false;
  userTypes : String[]= ['Employee','Manager'];
  dateOfJoining : any = '';
  dateOfBirth : any = '';
  userDepartments : String[]=['Java', 'DevOps', 'AWS', 'Angular', 'SAP', 'Python'];
  userGrade : String[]=['M1','M2','M3','M4','M5','M6','M7'] ;
  basicPayStatus : boolean = false;
  genderStatus : String[] = ['Male','Female'];
  maritalStatusStatus : String[] = ['	Single','Married','Divorced','Separated','Widowed'];
  homeAddressStatus : boolean = false;
  contactNoStatus : boolean = false;
  leaveBalanceStatus : boolean = false;
  leavesListStatus : boolean = false;
  managerIdStatus : boolean = false
    userr : User;

  submitted = false;
  angForm: FormGroup;
  //login : LoginComponent;
  constructor(private employeeService: EmployeeService, private router: Router, private fb: FormBuilder) {
    this.createForm();
   }

  ngOnInit() {
  }
  createForm() {
    this.angForm = this.fb.group({
         name: ['', Validators.required ]
    });
  }

  newEmployee(): void {
    this.submitted = false;
    this.user = new User();
  }

  registerEmployee() {
    this.employeeService.createEmployee(this.user).subscribe(data => {
        this.userr = data;
        if(this.userr.userId == null)
          this.router.navigate(['register']);
        else{
            this.router.navigate(['login']);
            alert("Registered Successfully");
        }
    });
    //this.employee = new Employee();
    //this.toastr.success('Employee Added Successfully!', 'Congratulations!');
            //this.router.navigate(['/login']);
            //this.login.ngOnInit();
        // if(emp!=null){
        //     alert("Employee successfully registered!");
        //     this.router.navigate(['login']);
        // }else{
        //   alert("Employee could not be registered!");
        //   this.router.navigate(['register']);
        // }
  }

  onSubmit() {
    this.submitted = true;
    this.registerEmployee();
  }

}
