import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Employee } from './model/employee';
import { ExpenseClaimModel } from './model/ExpenseClaim';
import { User } from './model/User';



@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  addExpenseClaim(claims:ExpenseClaimModel){
    return this.http.post<ExpenseClaimModel>("http://localhost:9004/ems/claim/addclaim",claims);
    }
   getEmployee(empId:String){
      return this.http.get<Employee>("http://localhost:9004/ems/employee/"+empId);
    }
  getExpenseCode(){
    return this.http.get<number[]>("http://localhost:9004/ems/expense");
  }

  getFinanceCode(){
    return this.http.get<number[]>("http://localhost:9004/ems/finance");
  }

  getProjectCode(){
    return this.http.get<number[]>("http://localhost:9004/ems/project");
  }
  updateExpenseClaim(claims:ExpenseClaimModel){
    return this.http.put<ExpenseClaimModel>("http://localhost:9004/ems/claim/modifyclaim",claims);
    }
 
  flag : boolean = false;
  user : User;
  employee : Employee;
  private baseUrl = 'http://localhost:9090/ems';
  constructor(private http: HttpClient) {
   }
  saveEmployee(user : User){
    console.log("saving user");
    this.user = user;
    console.log(user);
    console.log(sessionStorage);
    
  }
  
  createEmployee(user : User): Observable<User> {
    let form=new FormData();
        form.append("userId", String(user.userId));
        form.append("userFirstName",String(user.userFirstName));
        form.append("userLastName",String(user.userLastName));
        form.append("password", String(user.password));
        form.append("userType", String(user.userType));
        form.append("dateOfBirth", new Date(user.dateOfBirth).toUTCString());
        form.append("dateOfJoining", new Date(user.dateOfJoining).toUTCString());
        form.append("userDepartment", String(user.userDepartment));
        form.append("userGrade", String(user.userGrade));
        form.append("basicPay", String(user.basicPay));
        form.append("gender", String(user.gender));
        form.append("maritalStatus", String(user.maritalStatus));
        form.append("homeAddress", String(user.homeAddress));
        form.append("contactNo",String(user.contactNo));
        form.append("leaveBalance", String(user.leaveBalance));
        form.append("leavesList", String(user.leavesList));
        form.append("managerId", String(user.managerId));

    return this.http.post<User>(this.baseUrl+'/adduser', form);
  } 
  updateEmployee(pan: String, designation : String, domain : String, salary : number) {
    let form=new FormData();
        form.append("empId", sessionStorage.getItem('empId'));
        form.append("pan", String(pan));
        form.append("designation", String(designation));
        form.append("domain", String(domain));
        form.append("salary", String(salary))
        console.log(form);
        console.log(sessionStorage.getItem('empId'));
    return this.http.get<Employee>(this.baseUrl+'/update?empId='+sessionStorage.getItem('empId')+"&pan="+pan+"&designation="+designation+"&domain="+domain+"&salary="+salary);
  }
   deleteId(empId: string) : Observable<string> {
    console.log(empId);
    let form=new FormData();
    form.append("empId", empId);
    console.log(form);
    return this.http.get<string>(this.baseUrl+"/delete?empId="+empId);
  }
   
  searchDepartment(Department : String):Observable<User[]>{
    return this.http.get<User[]>(this.baseUrl+"/findByDepartment?Department="+Department);
  } 
  
   searchId(empId : string):Observable<Employee>{
    return this.http.get<Employee>(this.baseUrl+"/empId?empId="+empId);
  }
  searchDomain(domain : String):Observable<Employee[]>{
    return this.http.get<Employee[]>(this.baseUrl+"/domain?domain="+domain);
  }
  searchDesignation(designation : String):Observable<Employee[]>{
    return this.http.get<Employee[]>(this.baseUrl+"/designation?designation="+designation);
  } 
  loginEmployee(userId : string, password : string):Observable<User>{
    //let form = new FormData();
    //form.append("empId",empId);
    //form.append("password",password);
    console.log("in service angular");

    return this.http.get<User>(this.baseUrl+"/login/?userId="+userId+"&password="+password);
  }
   listEmployee() {
    return this.http.get<Employee[]>(this.baseUrl+"/");
  }
  changePassword(empId: string, oldPassword: string, newPassword: string):Observable<Employee> {
    let form = new FormData();
    form.append("empId",empId);
    form.append("oldPassword",oldPassword);
    form.append("newPassword",newPassword);
    return this.http.get<Employee>(this.baseUrl+"/password/?empId="+sessionStorage.getItem('empId')+"&oldPassword="+oldPassword+"&newPassword="+newPassword);
  } 
   /* addBank( bankName : string, accountNo : string, salary : string):Observable<any> {
    let form=new FormData();
        form.append("empId", String(this.employee.empId));
        form.append("bankName", String(bankName));
        form.append("accountNumber", String(accountNo));
    let params = new HttpParams().append('empId',this.employee.empId).append('bankName',bankName).append('accountNo',accountNo).append('salary', salary);
      return this.http.get(this.baseUrl+'/bank?empId='+sessionStorage.getItem('empId')+"&bankName="+bankName+"&accountNumber="+accountNo+"&salary="+salary);
    //return this.http.post(this.baseUrl+"/bank/"+this.employee.empId+"/"+bankName+"/"+accountNo);
  }
 */
    deleteEmployee() {
    console.log("Logged out successfully!")
    this.employee = null;
    sessionStorage.clear();
    alert("Logged out!");
  } 
    
}
