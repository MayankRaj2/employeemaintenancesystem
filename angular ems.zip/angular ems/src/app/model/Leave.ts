export class Leave{
    

    constructor(
        public leaveId : String = '',
        public noOfDays : String='',
        public reason : String='' ,
        public leaveStatus : String='' ,
       
       
        public viewStatus : boolean=true


    ){}
}