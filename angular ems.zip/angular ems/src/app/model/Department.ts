export class Department{
    

    constructor(
        public deptId : string = '',
        public deptName : String='',
       
       
        public viewStatus : boolean=true


    ){}
}