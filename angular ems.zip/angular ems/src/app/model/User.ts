import { Department } from "./Department";
import { Grade } from "./Grade";
import { Leave } from "./Leave";

export class User{
    constructor(){}

    public userId : string='' ;
    public userFirstName : String='';
    public userLastName : String='';
    public password : String='';
    public userType : String='';
    public dateOfBirth : any='';
    public dateOfJoining : any='';
    public userDepartment : Department;
    public userGrade : Grade;
    public basicPay : number=0.0;
    public gender : String='';
    public maritalStatus : String='';
    public homeAddress : String='';
    public contactNo : String='';
    public leaveBalance : String='';
    public leavesList : Leave[];
    public managerId : String=''
   
    
}