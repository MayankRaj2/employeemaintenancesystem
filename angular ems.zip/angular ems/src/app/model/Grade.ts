export class Grade{
    

    constructor(
        public gradeCode : String = '',
        public Description : String='',
        public minSalary : Number=0.0 ,
        public maxSalary : Number=0.0 ,
       
       
        public viewStatus : boolean=true


    ){}
}